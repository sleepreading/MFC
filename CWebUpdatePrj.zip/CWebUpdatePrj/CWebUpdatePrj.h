// CWebUpdatePrj.h : main header file for the CWEBUPDATEPRJ application
//

#if !defined(AFX_CWEBUPDATEPRJ_H__86AFC89C_0C5E_41B2_B6A9_2F6EA3EFED0D__INCLUDED_)
#define AFX_CWEBUPDATEPRJ_H__86AFC89C_0C5E_41B2_B6A9_2F6EA3EFED0D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCWebUpdatePrjApp:
// See CWebUpdatePrj.cpp for the implementation of this class
//

class CCWebUpdatePrjApp : public CWinApp
{
public:
	CCWebUpdatePrjApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCWebUpdatePrjApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCWebUpdatePrjApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CWEBUPDATEPRJ_H__86AFC89C_0C5E_41B2_B6A9_2F6EA3EFED0D__INCLUDED_)
