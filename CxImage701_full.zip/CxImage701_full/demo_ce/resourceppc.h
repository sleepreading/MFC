//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by demo_ceppc.rc
//
#define IDD_DEMO_CE_DIALOG              102
#define IDD_DEMO_CE_DIALOG_WIDE         103
#define IDR_MAINFRAME                   128
#define IDD_FILE_OPEN                   129
#define IDI_POCKET_16                   131
#define IDI_OPENFOLDER_16               132
#define IDI_CLOSEFOLDER_16              133
#define IDI_OPENPOCKET_16               134
#define IDR_FILEOPEN                    135
#define IDB_SORT_ARROWS                 137
#define IDC_STATIC_1                    200
#define IDC_BUTTON1                     1000
#define IDC_FILE_BTN                    1000
#define IDC_PICVIEW                     1001
#define IDC_FOLDER_TREE                 1002
#define IDC_FILE_LIST                   1003
#define IDR_MAIN_FILE                   32771
#define IDS_CAP_FILE                    32773
#define ID_VIEW_STANDARD                32774
#define ID_VIEW_TREE                    32776
#define ID_BAR_OK                       32779
#define ID_BAR_CANCEL                   32780
#define ID_FILE_EXIT                    32781
#define IDS_NEW                         65000
#define IDS_FILE                        65001
#define IDS_MHELP                       65002
#define IDS_SAVE                        65003
#define IDS_CUT                         65004
#define IDS_COPY                        65005
#define IDS_PASTE                       65006
#define IDS_ABOUT                       65007
#define IDS_EDIT                        65008
#define IDS_TOOL                        65009
// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
