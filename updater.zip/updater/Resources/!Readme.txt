Here you find several resources:

- Example of a small logo to use with Updater
- Example of a large logo to use with Updater
- Updater logo, to use as menu item in your application