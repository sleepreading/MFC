//*******************************************************************************
// COPYRIGHT NOTES
// ---------------
// This is a part of the BCGControlBar Library (Professional Version)
// Copyright (C) 1998-2014 BCGSoft Ltd.
// All rights reserved.
//
// This source code can be used, distributed or modified
// only under terms and conditions 
// of the accompanying license agreement.
//*******************************************************************************

#ifndef __BCGCBPROVER_H
#define __BCGCBPROVER_H

#define _BCGCBPRO_VERSION_		0x22010
#define _BCGCBPRO_VERSION_MAJOR	22
#define _BCGCBPRO_VERSION_MINOR	10
#endif __BCGCBPROVER_H
