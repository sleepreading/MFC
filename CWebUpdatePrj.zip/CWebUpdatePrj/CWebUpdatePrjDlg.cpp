// CWebUpdatePrjDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CWebUpdatePrj.h"
#include "CWebUpdatePrjDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCWebUpdatePrjDlg dialog

CCWebUpdatePrjDlg::CCWebUpdatePrjDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCWebUpdatePrjDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCWebUpdatePrjDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCWebUpdatePrjDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCWebUpdatePrjDlg)
	DDX_Control(pDX, IDC_UPDATES, m_Updates);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCWebUpdatePrjDlg, CDialog)
	//{{AFX_MSG_MAP(CCWebUpdatePrjDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDGETUPDATE2, OnDoCheck)
	ON_BN_CLICKED(IDGETUPDATE, OnGetUpdate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCWebUpdatePrjDlg message handlers

BOOL CCWebUpdatePrjDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// Create the imagelist
	m_Images.Create(32, 32, ILC_COLOR32 | ILC_MASK, 3, 1);
	m_Images.SetBkColor(RGB(255, 255, 255));

	// Add 2 images to it
	m_Images.Add(LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDI_NEW)));
	m_Images.Add(LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDI_UPDATED)));
	m_Images.Add(LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDI_NONE)));

	// Attach it to the CListBoxST
	m_Updates.SetImageList(&m_Images);

	// Set some update params
	updObj.SetLocalDirectory("", true);
	updObj.SetUpdateFileURL("http://herbdx.spatang.com/update.txt");
	updObj.SetRemoteURL("http://herbdx.spatang.com");

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCWebUpdatePrjDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CCWebUpdatePrjDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CCWebUpdatePrjDlg::OnDoCheck() 
{
	// Reset the list
	m_Updates.ResetContent();

	// The string we add to the list
	CString toAdd;

	// Do the update
	if (updObj.DoUpdateCheck())
	{
		// Retrieved file.. so we need to get the results

		// Missing files
		for (int i = 0; i < updObj.GetNumberMissing(); i++)
		{                 
			toAdd.Format("New module\n%s", updObj.GetMissingAt(i));
			m_Updates.AddString(toAdd, 0);
		}

		// Different files
		for (i = 0; i < updObj.GetNumberDifferent(); i++)
		{
			toAdd.Format("Module updated\n%s", updObj.GetDifferentAt(i));
			m_Updates.AddString(toAdd, 1);
		}
	}	

	if (m_Updates.GetCount() == 0)
	{
		toAdd.Format("No updates found\nGeneric Application is up to date");
		m_Updates.AddString(toAdd, 2);
	}
}

void CCWebUpdatePrjDlg::OnGetUpdate() 
{
	int imageNo;

	// Check if it's missing or different
	m_Updates.GetImage(m_Updates.GetCurSel(), &imageNo);

	if (imageNo == 0)
	{
		int numFile = m_Updates.GetCurSel();

		// It's a new file, download it
		if (updObj.DownloadMissing(numFile))
		{
			// Whacha, it succeeded
			CString messageBox = updObj.GetMissingAt(numFile) + " successfully downloaded";
			MessageBox(messageBox);
		}
		
		else
		{
			// It failed
			CString messageBox = updObj.GetMissingAt(numFile) + " failed to download";
			MessageBox(messageBox);
		}
	}

	else if (imageNo == 1)
	{
		int numFile = m_Updates.GetCurSel() - updObj.GetNumberMissing();

		// It's a different file, download it
		if (updObj.DownloadDifferent(numFile))
		{
			// Whacha, it succeeded
			CString messageBox = updObj.GetDifferentAt(numFile) + " successfully downloaded";
			MessageBox(messageBox);
		}
		
		else
		{
			// It failed
			CString messageBox = updObj.GetDifferentAt(numFile) + " failed to download";
			MessageBox(messageBox);
		}
	}

	else
	{
		MessageBox("There are no updates to download");
	}
}

void CCWebUpdatePrjDlg::OnCancel() 
{
	// Have fun :)
	CDialog::OnCancel();
}
